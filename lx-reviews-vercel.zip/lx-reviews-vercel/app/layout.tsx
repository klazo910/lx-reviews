
import "./globals.css"
import Link from "next/link"
import type { ReactNode } from "react"
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <header className="flex items-center justify-between mb-6">
            <h1 className="text-2xl md:text-3xl font-bold">Lube X‑press Reviews</h1>
            <nav className="flex gap-4 text-sm">
              <Link href="/" className="hover:underline">Overview</Link>
              <Link href="/leaderboard" className="hover:underline">Leaderboard</Link>
              <Link href="/snapshots" className="hover:underline">Daily Snapshots</Link>
              <Link href="/stores" className="hover:underline">Stores</Link>
            </nav>
          </header>
          {children}
        </div>
      </body>
    </html>
  )
}
