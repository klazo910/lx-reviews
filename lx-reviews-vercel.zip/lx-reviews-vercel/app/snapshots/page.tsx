
"use client"
import { useEffect, useState } from "react"
import { getLatestReviews } from "@/lib/metrics"
import { ReviewFeed } from "@/components/ReviewFeed"
import { STORES } from "@/lib/mockData"
export default function SnapshotsPage(){
  const [store, setStore] = useState<string>("All Stores")
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{ getLatestReviews(store).then(setItems) },[store])
  const stores = ["All Stores", ...STORES]
  return (
    <div className="grid gap-4">
      <div className="flex items-center gap-3">
        <label className="text-sm text-neutral-300 flex items-center gap-2">
          <span className="text-neutral-400">Store</span>
          <select className="bg-neutral-900 rounded-xl px-3 py-2" value={store} onChange={(e)=>setStore(e.target.value)}>
            {stores.map(i=> <option key={i} value={i}>{i}</option>)}
          </select>
        </label>
      </div>
      <ReviewFeed items={items} />
    </div>
  )
}
