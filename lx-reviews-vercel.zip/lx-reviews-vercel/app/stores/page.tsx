
import { getStoreComparisons } from "@/lib/metrics"
export default async function StoresPage(){
  const rows = await getStoreComparisons()
  return (
    <div className="grid gap-4">
      <h2 className="text-xl font-semibold">Store Leaderboard</h2>
      <div className="overflow-x-auto rounded-2xl">
        <table className="min-w-full text-sm">
          <thead className="bg-neutral-900">
            <tr>
              <th className="text-left p-3">Rank</th>
              <th className="text-left p-3">Store</th>
              <th className="text-right p-3">Avg Rating</th>
              <th className="text-right p-3">Positive Reviews</th>
              <th className="text-right p-3">Unique Techs</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i)=> (
              <tr key={r.store} className="odd:bg-neutral-900/50">
                <td className="p-3">{i+1}</td>
                <td className="p-3">{r.store}</td>
                <td className="p-3 text-right">{r.avgRating.toFixed(2)}</td>
                <td className="p-3 text-right">{r.positive}</td>
                <td className="p-3 text-right">{r.uniqueTechs}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
