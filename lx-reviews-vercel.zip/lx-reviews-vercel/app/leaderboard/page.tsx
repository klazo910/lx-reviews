
"use client"
import { useEffect, useMemo, useState } from "react"
import { fetchLeaderboard } from "@/lib/metrics"
import { LeaderTable } from "@/components/LeaderTable"
function ModeTabs({ value, onChange }: { value: "mentions"|"count", onChange: (v:"mentions"|"count")=>void }) {
  return (
    <div className="inline-flex rounded-xl overflow-hidden border border-neutral-800">
      <button className={`px-3 py-2 text-sm ${value==="mentions"?"bg-neutral-800":""}`} onClick={()=>onChange("mentions")}>Mentions</button>
      <button className={`px-3 py-2 text-sm ${value==="count"?"bg-neutral-800":""}`} onClick={()=>onChange("count")}>Review Count</button>
    </div>
  )
}
export default function LeaderboardPage() {
  const [mode, setMode] = useState<"mentions" | "count">("mentions")
  const [store, setStore] = useState<string>("All Stores")
  const [rows, setRows] = useState<any[]>([])
  useEffect(() => { fetchLeaderboard(mode, store).then(setRows) }, [mode, store])
  const stores = useMemo(() => ["All Stores", ...new Set(rows.map(r => r.store))] as string[], [rows])
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <ModeTabs value={mode} onChange={setMode} />
        <label className="text-sm text-neutral-300 flex items-center gap-2">
          <span className="text-neutral-400">Store</span>
          <select className="bg-neutral-900 rounded-xl px-3 py-2" value={store} onChange={(e)=>setStore(e.target.value)}>
            {stores.map(i=> <option key={i} value={i}>{i}</option>)}
          </select>
        </label>
      </div>
      <LeaderTable rows={rows} mode={mode} />
    </div>
  )
}
