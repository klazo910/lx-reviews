
import { getOverviewData } from "@/lib/metrics"
import { TrendChart } from "@/components/TrendChart"
import { KpiCard } from "@/components/KpiCard"
export default async function Page() {
  const data = await getOverviewData()
  return (
    <div className="grid gap-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard label="Positive Reviews" value={data.totalPositive.toLocaleString()} sub={data.rangeLabel} />
        <KpiCard label="Active Techs" value={data.activeTechs.toString()} sub="mentioned in 4★+ reviews" />
        <KpiCard label="Avg Rating" value={data.avgRating.toFixed(2)} sub="last 30 days" />
        <KpiCard label="Top Store" value={data.topStore.store} sub={`${data.topStore.count} reviews`} />
      </div>
      <section className="bg-neutral-900 rounded-2xl p-4">
        <h2 className="font-semibold mb-2">30‑Day Trend</h2>
        <TrendChart series={data.trend} />
      </section>
    </div>
  )
}
