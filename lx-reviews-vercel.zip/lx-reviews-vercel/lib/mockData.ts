
import type { Review } from "./types"
export const STORES = [
  "LX - Horizon", "LX - Lee Trevino", "LX - Mesa", "LX - Zaragoza", "LX - Dyer",
  "LX - Montana", "LX - Rojas", "LX - George Dieter", "LX - Transmountain", "LX - Yarbrough",
  "LX - Doniphan", "LX - Alameda", "LX - McRae"
]
export const TECHS_BY_STORE: Record<string, string[]> = {
  "LX - Horizon": ["Israel", "Marco", "Luis"],
  "LX - Lee Trevino": ["Ana", "Jorge", "Kevin"],
  "LX - Mesa": ["Diego", "Pablo"],
  "LX - Zaragoza": ["Rene", "Oscar"],
  "LX - Dyer": ["Gil", "Chris"],
  "LX - Montana": ["Leo", "Ivan"],
  "LX - Rojas": ["Alex", "Ricky"],
  "LX - George Dieter": ["David", "Mario"],
  "LX - Transmountain": ["Victor", "Nick"],
  "LX - Yarbrough": ["Angel", "Brian"],
  "LX - Doniphan": ["Juan", "Jose"],
  "LX - Alameda": ["Sergio", "Carlos"],
  "LX - McRae": ["Eddie", "Noah"]
}
export const MOCK_REVIEWS: Review[] = (() => {
  const out: Review[] = []
  const now = new Date()
  let id = 1
  for (let d = 0; d < 30; d++){
    const day = new Date(now.getTime() - d * 86400000)
    const n = 3 + Math.floor(Math.random()*4)
    for (let i=0;i<n;i++){
      const store = STORES[Math.floor(Math.random()*STORES.length)]
      const rating = Math.random() < 0.7 ? 5 : 4
      const techNames = TECHS_BY_STORE[store]
      const tech = Math.random() < 0.7 ? techNames[Math.floor(Math.random()*techNames.length)] : undefined
      const comment = tech ? `${tech} was awesome! Fast and friendly oil change.` : `Great team! Quick service and fair price.`
      out.push({ id: String(id++), store, rating, comment, reviewer: "Google User", date: day.toISOString(), tech, link: "#" })
    }
  }
  return out
})()
