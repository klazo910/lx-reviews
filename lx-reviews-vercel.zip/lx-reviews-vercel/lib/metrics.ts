
import { MOCK_REVIEWS, STORES } from "./mockData"
import type { Review } from "./types"
import { computeBadges } from "./badges"
export async function getOverviewData(){
  const last30 = filterPositive(MOCK_REVIEWS).filter(r=> Date.now()-+new Date(r.date) <= 30*86400000)
  const totalPositive = last30.length
  const activeTechs = new Set(last30.map(r=>r.tech).filter(Boolean)).size
  const avgRating = avg(last30.map(r=>r.rating))
  const byStore: Record<string, number> = {}
  for (const r of last30){ byStore[r.store] = (byStore[r.store]||0)+1 }
  const topStore = Object.entries(byStore).sort((a,b)=> (b[1] as number) - (a[1] as number))[0] || ["—",0]
  const trend = buildTrend(last30)
  return { totalPositive, activeTechs, avgRating, topStore: { store: topStore[0], count: topStore[1] as number }, trend, rangeLabel: "last 30 days" }
}
export async function fetchLeaderboard(mode: "mentions"|"count", store: string){
  const revs = filterPositive(MOCK_REVIEWS).filter(r => store === "All Stores" ? true : r.store === store)
  const byTech = new Map<string, Review[]>()
  for (const r of revs){
    const key = `${r.tech || "Team"}||${r.store}`
    if (!byTech.has(key)) byTech.set(key, [])
    byTech.get(key)!.push(r)
  }
  const rows = Array.from(byTech.entries()).map(([k, reviews])=>{
    const [tech, store] = k.split("||")
    const avgRating = avg(reviews.map(r=>r.rating))
    const mentions = reviews.filter(r=>!!r.tech).length
    const badges = tech === "Team" ? [] : computeBadges(reviews)
    return { tech, store, avgRating, mentions, positive: reviews.length, badges }
  })
  rows.sort((a,b)=> (mode === "mentions" ? b.mentions - a.mentions : b.positive - a.positive))
  return rows
}
export async function getLatestReviews(store: string){
  const revs = filterPositive(MOCK_REVIEWS)
    .filter(r => store === "All Stores" ? true : r.store === store)
    .sort((a,b)=> +new Date(b.date) - +new Date(a.date))
    .slice(0, 50)
  return revs
}
export async function getStoreComparisons(){
  const revs = filterPositive(MOCK_REVIEWS)
  const byStore = STORES.map(s => {
    const rs = revs.filter(r=>r.store===s)
    const avgRating = rs.length ? avg(rs.map(r=>r.rating)) : 0
    const uniqueTechs = new Set(rs.map(r=>r.tech).filter(Boolean)).size
    return { store: s, avgRating, positive: rs.length, uniqueTechs }
  })
  byStore.sort((a,b)=> b.avgRating - a.avgRating || b.positive - a.positive)
  return byStore
}
function filterPositive(rs: Review[]){ return rs.filter(r=> r.rating >= 4) }
function avg(nums: number[]){ return nums.length ? nums.reduce((a,b)=>a+b,0)/nums.length : 0 }
function buildTrend(rs: Review[]){
  const days: Record<string, number> = {}
  for (let i=29;i>=0;i--){
    const d = new Date(Date.now()-i*86400000)
    const key = d.toISOString().slice(0,10)
    days[key] = 0
  }
  for (const r of rs){ const k = r.date.slice(0,10); if (k in days) days[k]++ }
  return Object.entries(days).map(([date,count])=> ({ date, count }))
}
