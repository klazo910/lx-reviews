
import type { Review } from "./types"
export function computeBadges(reviews: Review[]): string[] {
  const fiveStar = reviews.filter(r=>r.rating===5)
  const badges: string[] = []
  if (fiveStar.length >= 5) badges.push("5‑Star Streak")
  if (reviews.length >= 10) badges.push("Bronze")
  if (reviews.length >= 25) badges.push("Silver")
  if (reviews.length >= 50) badges.push("Gold")
  const latest = [...reviews].sort((a,b)=> +new Date(b.date)-+new Date(a.date))[0]
  if (latest && (Date.now() - +new Date(latest.date)) < 48*3600*1000) badges.push("Speedy Service")
  return badges
}
