
export type Review = {
  id: string
  store: string
  rating: number
  comment: string
  reviewer?: string
  date: string
  tech?: string
  link?: string
}
