
"use client"
function BadgePill({ label }: { label: string }){
  return (
    <span className="inline-block text-xs bg-emerald-600/20 text-emerald-300 px-2 py-1 rounded-full border border-emerald-500/30">
      {label}
    </span>
  )
}
export function LeaderTable({ rows, mode }: { rows: any[], mode: "mentions"|"count" }){
  return (
    <div className="overflow-x-auto bg-neutral-900 rounded-2xl">
      <table className="min-w-full text-sm">
        <thead>
          <tr>
            <th className="text-left p-3">Rank</th>
            <th className="text-left p-3">Technician</th>
            <th className="text-left p-3">Store</th>
            <th className="text-right p-3">{mode === "mentions" ? "Mentions" : "Pos Reviews"}</th>
            <th className="text-right p-3">Avg ★</th>
            <th className="text-left p-3">Badges</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r:any, i:number)=> (
            <tr key={`${r.tech}-${i}`} className="odd:bg-neutral-900/60">
              <td className="p-3">{i+1}</td>
              <td className="p-3 font-medium">{r.tech}</td>
              <td className="p-3">{r.store}</td>
              <td className="p-3 text-right">{mode === "mentions" ? r.mentions : r.positive}</td>
              <td className="p-3 text-right">{r.avgRating.toFixed(2)}</td>
              <td className="p-3 flex gap-2 flex-wrap">
                {r.badges.map((b:string)=> <BadgePill key={b} label={b} />)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
