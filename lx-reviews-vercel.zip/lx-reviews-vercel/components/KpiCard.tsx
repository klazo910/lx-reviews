
export function KpiCard({ label, value, sub }: { label: string, value: string, sub?: string }){
  return (
    <div className="bg-neutral-900 rounded-2xl p-4">
      <div className="text-neutral-400 text-xs uppercase tracking-wide">{label}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
      {sub && <div className="text-neutral-400 text-xs mt-1">{sub}</div>}
    </div>
  )
}
