
"use client"
import { format } from "date-fns"
export function ReviewFeed({ items }: { items: any[] }){
  return (
    <div className="grid gap-3">
      {items.map((r)=> (
        <div key={r.id} className="bg-neutral-900 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div className="font-medium">{r.store}</div>
            <div className="text-yellow-400">{"★".repeat(r.rating)}<span className="text-neutral-500 ml-1">({r.rating})</span></div>
          </div>
          <div className="text-neutral-300 mt-2">{r.comment}</div>
          <div className="text-xs text-neutral-500 mt-2 flex gap-3 flex-wrap">
            <span>{r.reviewer || "Google User"}</span>
            <span>•</span>
            <span>{format(new Date(r.date), "MMM d, yyyy p")}</span>
            {r.tech && (<><span>•</span><span>Tech: <b>{r.tech}</b></span></>)}
            {r.link && (<><span>•</span><a className="underline" href={r.link} target="_blank" rel="noreferrer">View</a></>)}
          </div>
        </div>
      ))}
    </div>
  )
}
